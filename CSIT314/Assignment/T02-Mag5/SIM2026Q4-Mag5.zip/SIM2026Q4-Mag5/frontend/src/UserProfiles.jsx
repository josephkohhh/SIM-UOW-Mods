import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import "./UserProfiles.css";
import "./adminportal.css";
import logo from "./Image/logo.png";

const API = "http://127.0.0.1:8000/get_all_userprofile";

export default function UserProfiles({ logout }) {
  const [profiles, setProfiles] = useState([]);
  const [search, setSearch] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [editId, setEditId] = useState(null);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [error, setError] = useState("");

  // Load profile types from FastAPI.
  async function loadProfiles() {
    try {
      const response = await fetch("http://127.0.0.1:8000/get_all_userprofile");
      if (!response.ok) throw new Error("Unable to load profiles");
      setProfiles(await response.json());
      setError("");
    } catch (err) {
      setError(err.message);
    }
  }

  useEffect(() => {
    loadProfiles();
  }, []);

  function addProfile() {
    setEditId(null);
    setName("");
    setDescription("");
    setShowForm(true);
  }

  function editProfile(profile) {
    setEditId(profile.profile_id);
    setName(profile.role);
    setDescription(profile.description);
    setShowForm(true);
  }

  async function saveProfile(event) {
    event.preventDefault();

    const existing = profiles.find((profile) => profile.profile_id === editId);

    const data = {
      role: name.trim(),
      description: description.trim(),
    };

    try {
      const response = await fetch(
        editId === null
          ? "http://127.0.0.1:8000/create_userprofile"
          : `http://127.0.0.1:8000/update_userprofile?role=${encodeURIComponent(existing.role)}`,
        {
          method: editId === null ? "POST" : "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(data),
        },
      );
      if (!response.ok) {
        const errorData = await response.json();
        console.log("Backend error:", errorData);
        throw new Error(JSON.stringify(errorData));
      }

      setShowForm(false);
      await loadProfiles();
    } catch (err) {
      setError(err.message);
    }
  }

  // Delete Profile
  async function deleteProfile(profile) {
    const confirmDelete = window.confirm(
      `Are you sure you want to delete ${profile.role}?`,
    );

    if (!confirmDelete) return;

    try {
      const response = await fetch(
        `http://127.0.0.1:8000/delete_userprofile/${encodeURIComponent(profile.role)}`,
        {
          method: "DELETE",
        },
      );

      if (!response.ok) {
        const errorData = await response.json();
        console.log("Backend error:", errorData);
        throw new Error("Unable to delete profile");
      }

      alert("Profile deleted successfully");
      await loadProfiles();
    } catch (err) {
      setError(err.message);
    }
  }

  const filteredProfiles = profiles.filter((profile) =>
    (profile.role ?? "").toLowerCase().includes(search.toLowerCase()),
  );

  return (
    <div className="AdminPortal_page">
      {/* SIDEBAR */}
      <aside className="AdminPortal_navbar">
        <img src={logo} alt="LOGO" />

        <nav className="AdminPortal_menu">
          <Link to="/admin_portal">Users Account</Link>

          <Link to="/admin_portal/user_profiles" className="active">
            User Profiles
          </Link>
        </nav>

        <button type="button" className="signout" onClick={logout}>
          Sign out
        </button>
      </aside>

      {/* MAIN CONTENT */}
      <main className="AdminPortal_content">
        <div className="user-profiles-page">
          <h2>User Profiles</h2>

          <div className="user-profiles-panel">
            <h3>All User Profiles</h3>

            <input
              className="profile-search"
              type="text"
              placeholder="Search user profile name"
              value={search}
              onChange={(event) => setSearch(event.target.value)}
            />

            <button className="profile-add" onClick={addProfile}>
              + Add User Profile
            </button>

            {showForm && (
              <form className="profile-form" onSubmit={saveProfile}>
                <h3>
                  {editId === null ? "Add User Profile" : "Edit User Profile"}
                </h3>

                <label>Profile Name</label>

                <input
                  value={name}
                  onChange={(event) => setName(event.target.value)}
                  required
                />

                <label>Description</label>

                <input
                  value={description}
                  onChange={(event) => setDescription(event.target.value)}
                  required
                />

                <div className="profile-form-actions">
                  <button type="submit">Save</button>

                  <button type="button" onClick={() => setShowForm(false)}>
                    Cancel
                  </button>
                </div>
              </form>
            )}

            {error && <p className="profile-error">{error}</p>}

            <div className="profile-table-scroll">
              <table className="profile-table">
                <thead>
                  <tr>
                    <th>Profile Name</th>
                    <th>Description</th>
                    <th>Actions</th>
                  </tr>
                </thead>

                <tbody>
                  {filteredProfiles.map((profile) => (
                    <tr key={profile.profile_id}>
                      <td>{profile.role}</td>
                      <td>{profile.description}</td>

                      <td>
                        <button
                          className="profile-edit"
                          onClick={() => editProfile(profile)}
                        >
                          Edit
                        </button>
                        <button
                          className="profile-delete"
                          onClick={() => deleteProfile(profile)}
                        >
                          Delete
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>

              {filteredProfiles.length === 0 && (
                <p className="profile-empty">No matching profiles found.</p>
              )}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
